#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	//depends where 'sample.txt' file is located
	fp=fopen("e:\\myfiles\\sample.txt","w");
	if(!fp)
	{
		cout << "Cannot open file. \n";
		system ("pause");
		exit(1);
	}
	for (int i = 65;i<91;i++)
		fputc(i, fp);
	fclose(fp);
	return 0;
}
