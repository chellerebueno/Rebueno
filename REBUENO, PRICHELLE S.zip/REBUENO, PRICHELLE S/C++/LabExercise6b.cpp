#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	//depends where 'sample.txt' file is located
	fp=fopen("d:\\myfiles\\sample.txt","r");
	if(!fp)
	{
		cout << "Cannot open file. \n";
		system ("pause");
		exit(1);
	}
	char c;
	while((c = fgetc(fp))!=EOF)
		cout << c;
		
	fclose(fp);
	system ("pause > 0");
	return 0;
}
