#include <iostream>
using namespace std;

int Array [11][11];
void printArray()
{
	for (int i=1;i<=10;i++)
	{
		for (int j=1;j<=10;j++)
		{
			cout << Array[i][j];
		}
	}
}

void printCol()
{
	for (int i=1;i<=10;i++)
	{
		for (int j=1;j<=10;j++)
		{
			cout << Array[j][i] << endl;
		}
	}
}

void printRow()
{
	for (int i=1;i<=10;i++)
	{
		for (int j=1;j<=10;j++)
		{
			cout << Array[i][j] << " ";
		}
	}
}

int main()
{
	string Picker;
	for (int i=1;i<=10;i++)
	{
		for (int j=1;j<=10;j++)
		{
			cout << "ENTER A NUMBER [Row [" << i << "] Column [" << j <<"]]: ";
			cin >> Array[i][j];
		}
	}
	cout << "Would you like to print: ";
	cout << "I.Array" << endl << "II. Column" << endl << "III. Row" <<endl << " >> ";
	cin >> Picker;
	if (Picker == "Array")
	{
		printArray();
	}
	else if (Picker == "Column")
	{
		printCol();
	}
	else if (Picker == "Row")
	{
		printRow();
	}
	
}
