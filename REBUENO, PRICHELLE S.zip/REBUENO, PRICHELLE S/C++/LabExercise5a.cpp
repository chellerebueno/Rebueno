#include<iostream>
#include<string.h>
using namespace std;

struct StudentRecord
{
	int ID;
	char Name[40];
	int Quiz[5] = {0,0,0,0,0}; 
};



int main()
{
	int sum = 0;
	int total = 0;
	string remarks;
	
	struct StudentRecord rec;
	cout << "Enter Student Record:" << endl;
	
	cout << "ID: ";
	cin >> rec.ID;
	cin.ignore();
	cout << "Name: ";
	cin.get(rec.Name,39);
	for(int i = 1; i <= 3; i++)
	{
		cout << "Quiz " << i << ": ";
		cin >> rec.Quiz[i];
	}
	
	for(int i = 1; i <= 3; i++)
	{
		sum += rec.Quiz[i];	
	}
	total = sum / 3;
	if(total >= 75)
	{
		remarks = "PASSED";
	}else{
		remarks = "FAILED";
	}
	cout << endl << "Student Record: " << endl;
	cout << "ID: " << rec.ID << endl;
	cout << "Name: " << rec.Name << endl;
	cout << "Grade: " << total << endl;
	cout << "Remarks: " << remarks << endl;
}
