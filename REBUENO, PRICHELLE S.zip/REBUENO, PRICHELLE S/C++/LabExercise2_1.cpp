#include <iostream>
#include <string.h>
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <limits>
#include <conio.h>

using namespace std;

int square();
int rectangle();
int triangle();
int circle();

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}


//OUTSIDE BORDER
void border_out()
{
	int y2=2, y3=40, x2=2, x3=110;

	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y2);cout << (char)219 << endl;
	}
	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y3); cout << (char)219 << endl;
	}
	for(int y1=2; y1<40; y1++)
	{
		gotoxy(x2,y1); cout << (char)219 << endl;
	}
	for(int y1=2; y1<41; y1++)
	{
		gotoxy(x3,y1); cout << (char)219 << endl;
	}
}

	

//INNER	
void border_in()
{
	int b2=10, b3=30, a2=30, a3=90;
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b2); cout << (char)219 << endl;
	}
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b3); cout << (char)219 << endl;
	}
	for(int b1=10; b1<30; b1++)
	{
		gotoxy(a2,b1); cout << (char)219 << endl;
	}
	for(int b1=10; b1<31; b1++)
	{
		gotoxy(a3,b1); cout << (char)219 << endl;
	}
}

int main()
{
system ("COLOR 80");
system("cls");
int choice;
	border_out();
	border_in();
	gotoxy(57,13); cout << "M E N U";
	gotoxy(47,15);cout << "PRESS (1) AREA OF A SQUARE";
	gotoxy(47,17);cout << "PRESS (2) AREA OF A RECTANGLE";
	gotoxy(47,19);cout << "PRESS (3) AREA OF A TRIANGLE";
	gotoxy(47,21);cout << "PRESS (4) AREA OF A CIRCLE";
	gotoxy(47,23);cout << "PRESS (5) EXIT";
	gotoxy(55,25);cout << "Select One: ";
	
	cin >> choice;
	switch(choice)
	{
		case 1: square(); break;
		case 2: rectangle(); break;
		case 3: triangle(); break;
		case 4: circle(); break;
		case 5: exit (0); break;
		default: gotoxy(45,28); cout << "I N V A L I D   I N P U T ! ! ! "; break;
	}	
	
	getch();
}

int square()
{
	system("CLS");
	system ("COLOR 08");
   int s_area, s_side;
  	 border_out();
	gotoxy(47,5); cout << "A R E A   O F   A   S Q U A R E " ;
	gotoxy(29,7);cout << "INSTRUCTION: ENTER THE SIDE OF A SQUARE AND DISPLAY ITS AREA. \n\n";
	border_in();

   gotoxy(33,17);cout << "ENTER THE SIDE OF A SQUARE: ";
   cin >> s_side;
	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
   s_area = s_side * s_side;

   gotoxy(33,21);cout << "AREA OF A SQUARE: " << s_area << " sq. units" << endl;
   
int option;
gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> option;
	if(option==1)
	{
		return square();
	}
	else if(option==2)
	{
		return main();
	}
	else if(option==3)
	{
		exit(0);
	}
	getch();
}



//RECTANGLE
int rectangle()
{
	system("CLS");
	system ("COLOR 08");
   	int length,width;
	int r_area=0;
  	border_out();
	gotoxy(43,5); cout << "A R E A   O F   A   R E C T A N G L E " ;
	gotoxy(25,7);cout << "INSTRUCTION: ENTER THE LENGTH AND WIDTH OF A RECTANGLE AND DISPLAY ITS AREA. \n\n";
	border_in();

   gotoxy(33,17);cout << "ENTER LENGTH AND WIDTH OF A RECTANGLE: ";
   gotoxy(73,17);cin>>length>>width;

	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
	r_area=length*width;

	gotoxy(33,21);cout<<"AREA OF RECTANGLE: " << r_area << " sq. units" << endl;
   
int option;
gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> option;
	if(option==1)
	{
		return rectangle();
	}
	else if(option==2)
	{
		return main();
	}
	else if(option==3)
	{
		exit(0);
	}
	getch();
}

//triangle
int triangle()
{
	system("CLS");
	system ("COLOR 08");
     int base, height;
    float t_area;
  	border_out();
	gotoxy(45,5); cout << "A R E A   O F   A   T R I A N G L E " ;
	gotoxy(25,7);cout << "INSTRUCTION: ENTER THE BASE AND HEIGHT OF A TRIANGLE AND DISPLAY ITS AREA. \n\n";
	border_in();

   gotoxy(33,17);cout << "ENTER BASE AND HEIGHT OF A TRIANGLE: ";
   gotoxy(71,17);cin>>base>>height;

	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
    t_area= (0.5)*base*height;
 
    gotoxy(33,21);cout<<"AREA OF A TRIANGLE: " << t_area << " sq units" << endl;
   
int option;
	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> option;
	if(option==1)
	{
		return triangle();
	}
	else if(option==2)
	{
		return main();
	}
	else if(option==3)
	{
		exit(0);
	}
	getch();
}


int circle()
{
	system("CLS");
	system ("COLOR 08");
   	float radius, c_area;
  	border_out();
	gotoxy(45,5); cout << "A R E A   O F   A   C I R C L E " ;
	gotoxy(30,7);cout << "INSTRUCTION: ENTER THE RADIUS OF A CIRCLE AND DISPLAY ITS AREA. \n\n";
	border_in();

   gotoxy(33,17);cout << "ENTER THE RADIUS OF A CIRCLE: ";
   gotoxy(63,17); cin >> radius;

	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
   c_area = 3.14 * radius * radius;
   gotoxy(33,21);cout << "AREA OF A CIRCLE: " << c_area << " sq. units" << endl;
   
int option;
	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";	
	cin >> option;
	if(option==1)
	{
		return circle();
	}
	else if(option==2)
	{
		return main();
	}
	else if(option==3)
	{
		exit(0);
	}
	getch();
}



