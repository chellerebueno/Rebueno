#include <iostream>
#include <string.h>
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <conio.h>
using namespace std;

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

//OUTSIDE BORDER
void border_out()
{
	int y2=2, y3=40, x2=2, x3=110;

	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y2);cout << (char)219 << endl;
	}
	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y3); cout << (char)219 << endl;
	}
	for(int y1=2; y1<40; y1++)
	{
		gotoxy(x2,y1); cout << (char)219 << endl;
	}
	for(int y1=2; y1<41; y1++)
	{
		gotoxy(x3,y1); cout << (char)219 << endl;
	}
}

	

//INNER	
void border_in()
{
	int b2=10, b3=30, a2=30, a3=90;
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b2); cout << (char)219 << endl;
	}
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b3); cout << (char)219 << endl;
	}
	for(int b1=10; b1<30; b1++)
	{
		gotoxy(a2,b1); cout << (char)219 << endl;
	}
	for(int b1=10; b1<31; b1++)
	{
		gotoxy(a3,b1); cout << (char)219 << endl;
	}
}

int Compare(const char* str1,const char *str2)
{
	while(*str1 == *str2)
	{
		if(*str1 == '\0')
		
		return 0;
		
		str1++;
		str2++;
	}
	
	return(*str1-*str2);
}

int main()
{
	
			system ("COLOR 08");
			system("CLS");
			border_out();
			border_in();
	char one[10];
	char two[10];
	
	gotoxy (35,17);cout << "Enter a data: ";
				gotoxy (49,17);cin >> one;
				gotoxy (35,19);cout << "Enter another data:  ";
				gotoxy (55,19);cin >> two;
	
	
	if(Compare(one,two) == 0)
	{
		gotoxy (55,23);cout << "T R U E";
	}else{
		gotoxy (55,23);cout << "F A L S E";
	}
	getch();
}
