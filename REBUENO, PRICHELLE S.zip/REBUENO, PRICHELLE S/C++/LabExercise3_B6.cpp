#include <iostream>
#include <string>
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <iomanip>
#include <conio.h>
using namespace std;

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

//OUTSIDE BORDER
void border_out()
{
	int y2=2, y3=40, x2=2, x3=110;

	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y2);cout << (char)219 << endl;
	}
	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y3); cout << (char)219 << endl;
	}
	for(int y1=2; y1<40; y1++)
	{
		gotoxy(x2,y1); cout << (char)219 << endl;
	}
	for(int y1=2; y1<41; y1++)
	{
		gotoxy(x3,y1); cout << (char)219 << endl;
	}
}

	

//INNER	
void border_in()
{
	int b2=10, b3=30, a2=30, a3=90;
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b2); cout << (char)219 << endl;
	}
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b3); cout << (char)219 << endl;
	}
	for(int b1=10; b1<30; b1++)
	{
		gotoxy(a2,b1); cout << (char)219 << endl;
	}
	for(int b1=10; b1<31; b1++)
	{
		gotoxy(a3,b1); cout << (char)219 << endl;
	}
}

int stringCheck ()
{
 char word[50];
                    int len;
                    do { system("CLS"); border_out(); gotoxy(25,7);
                    cout << "SPLIT AND REVERSE STRING" << endl;
                    gotoxy(20,10); cout << "Splits the string in to word and ";
                    gotoxy(20,11); cout << "display in reverse vertical order";
                    gotoxy(5,16); cout << "Enter some string: ";
                    do{ gotoxy(25,16); cout << "\t\t\t\t"; gotoxy(25,16);
                    cin.getline(word,50);}
                    while(!stringCheck(word));
                    len = stringLength(word);
                    gotoxy(32,20); cout << "RESULT" << endl;
                    //gotoxy(70/2-len/2,21);
                    for (int i = len - 1,j = 1; i >= 0, j < len; i--,j++) {
                    if (word[i] == ' ')
                    {
                        word[i] = '\0';
                        cout << setw(35) << &(word[i]) + 1  << "\n";
                    }
                        }
                    cout << setw(35) << word;
					border();
                    gotoxy(70/2 - 7,28); cout << "TRY AGAIN [1]";
                    gotoxy(70/2 - 7,30); cout << "MAIN MENU [2]";
                    gotoxy(70/2 - 4,32); cout << "EXIT [3]";
                    gotoxy(31,34); cout << "[     ]";
                    gotoxy(34,34);cin >>  repeat;
                    if(repeat == 1)
                        {again = true; }
                    else if( repeat == 2)
                        {menuAgain = true; }
                    else
                        exit(0);
                                        }
                    while(again==true);break;
                }
