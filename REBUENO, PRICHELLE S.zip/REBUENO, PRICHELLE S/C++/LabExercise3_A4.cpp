#include <iostream>
#include <string.h>
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <limits>
#include <conio.h>

using namespace std;

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int ascending();
int decbin();
int highlow();
int palindrome();


//OUTSIDE BORDER
void border_out()
{
	int y2=2, y3=40, x2=2, x3=110;

	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y2);cout << (char)219 << endl;
	}
	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y3); cout << (char)219 << endl;
	}
	for(int y1=2; y1<40; y1++)
	{
		gotoxy(x2,y1); cout << (char)219 << endl;
	}
	for(int y1=2; y1<41; y1++)
	{
		gotoxy(x3,y1); cout << (char)219 << endl;
	}
}

	

//INNER	
void border_in()
{
	int b2=10, b3=30, a2=30, a3=90;
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b2); cout << (char)219 << endl;
	}
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b3); cout << (char)219 << endl;
	}
	for(int b1=10; b1<30; b1++)
	{
		gotoxy(a2,b1); cout << (char)219 << endl;
	}
	for(int b1=10; b1<31; b1++)
	{
		gotoxy(a3,b1); cout << (char)219 << endl;
	}
}


int main ()
	{
	system ("COLOR 08");
	system("CLS");
	char word[50];
    int i, length;
    int j = 0;
    border_out();
	gotoxy(47,5); cout << "P A L I N D R O M E" ;
	gotoxy(29,7);cout << "INSTRUCTION: ENTER A WORD AND DISPLAY IF IT IS A PALINDROME OR NOT. \n\n";
	border_in();
    
    gotoxy(47,17);cout << "ENTER A WORD: "; 
	gotoxy(62,17);cin >> word;
		while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
	
    length = strlen(word);
    
    for(i=0;i < length ;i++){
        if(word[i] != word[length-i-1]){
            j = 1;
            break;
   }
}
    
    if (j) {
        gotoxy(47,23);cout << word << " IS NOT A PALINDROME" << endl; 
    }    
    else {
        gotoxy(47,23);cout << word << " IS A PALINDROME" << endl; 
    }
    getch();
}
    
