#include <iostream>
#include <string.h>
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <limits>
#include <conio.h>

using namespace std;

void gotoxy(int x, int y)
{
	COORD coord;
	coord.X=x;
	coord.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

int ascending();
int decbin();
int highlow();
int palindrome();


//OUTSIDE BORDER
void border_out()
{
	int y2=2, y3=40, x2=2, x3=110;

	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y2);cout << (char)219 << endl;
	}
	for(int x1=2; x1<110; x1++)
	{
		gotoxy(x1,y3); cout << (char)219 << endl;
	}
	for(int y1=2; y1<40; y1++)
	{
		gotoxy(x2,y1); cout << (char)219 << endl;
	}
	for(int y1=2; y1<41; y1++)
	{
		gotoxy(x3,y1); cout << (char)219 << endl;
	}
}

	

//INNER	
void border_in()
{
	int b2=10, b3=30, a2=30, a3=90;
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b2); cout << (char)219 << endl;
	}
	for(int a1=30; a1<90; a1++)
	{
		gotoxy(a1,b3); cout << (char)219 << endl;
	}
	for(int b1=10; b1<30; b1++)
	{
		gotoxy(a2,b1); cout << (char)219 << endl;
	}
	for(int b1=10; b1<31; b1++)
	{
		gotoxy(a3,b1); cout << (char)219 << endl;
	}
}

int main()
{
system ("COLOR 80");
system("cls");
int choice;
	border_out();
	border_in();
	gotoxy(57,13); cout << "M E N U";
	gotoxy(47,15);cout << "PRESS (1) ASCENDING ORDER";
	gotoxy(47,17);cout << "PRESS (2) DECIMAL TO BINARY";
	gotoxy(47,19);cout << "PRESS (3) HIGHEST AND LOWEST";
	gotoxy(47,21);cout << "PRESS (4) PALINDROME";
	gotoxy(55,23);cout << "Select One: ";
	cin >> choice;
	switch(choice)
	{
		case 1: ascending(); break;
		case 2: decbin(); break;
		case 3: highlow(); break;
		case 4: palindrome(); break;
		default: gotoxy(45,27);cout << "I N V A L I D  I N P U T ! ! ! "; break;
	}	
	getch ();
}

//PROBLEM 1//
int ascending()
{
system ("COLOR 08");
	system("CLS");
	int a[10], x, y, temp;
	
	border_out();
	gotoxy(47,5); cout << "A S C E N D I N G   O R D E R " ;
	gotoxy(29,7);cout << "INSTRUCTION: ENTER 10 NUMBERS AND DISPLAY IT IN ASCENDING ORDER. \n\n";
	border_in();

 	gotoxy(33,13);cout<<"ENTER 10 NUMBERS: \n";
 	for(x=0;x<10;x++)
 	{
	gotoxy (33,14+x);cin >> a[x];
	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
 	}
	
 	for(x=0;x<=10;x++)
 	{
 	for(y=0;y<=10-x;y++)
 	{
 	if(a[y]>a[y+1])
 	{
 	temp=a[y];
 	a[y]=a[y+1];
 	a[y+1]=temp;
 	}
 	}
 	}

	gotoxy(33,26);cout<<"ASCENDING ORDER: ";
 	for(y=0;y<10;y++)
 	{
	cout << a[y] <<' ';
	}
	int b;
	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> b;
		if(b==1)
		{
			return ascending();
		}
		else if(b==2)
		{
			return main();
		}
		else if(b==3)
		{
			exit(0);
		}
	}


//PROB 2/

int decbin ()
{
	system ("COLOR 08");
	system("CLS");
	int a[10], x, y;
	border_out();
	gotoxy(45,5); cout << "D E C I M A L   T O   B I N A R Y" ;
	gotoxy(27,7);cout << "INSTRUCTION: CONVERT A DECIMAL NUMBER TO ITS EQUIVALENT BINARY NUMBER. \n\n";
	border_in();

 	gotoxy(47,17);cout<<"ENTER A DECIMAL NUMBER: \n" ;   
	gotoxy(71,17);cin>>x;    
	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
	for(y=0; x>0; y++)    
	{	    
		a[y]=x%2;    
		x= x/2;  
	}    
	gotoxy(47,23);cout<<"BINARY EQUIVALENT: ";    
	for(y=y-1 ;y>=0 ;y--)    
	{    
		cout<<a[y];    
	}  
	
	int b;

	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> b;
	if(b==1)
	{
		return decbin();
	}
	else if(b==2)
	{
		return main();
	}
	else if(b==3)
	{
		exit(0);
	}
}


//PROB 3/////
int highlow ()
{
	system ("COLOR 08");
	system("CLS");
 int num[50], largest, second, lowest, secondlow;
 	border_out();
	gotoxy(44,5); cout << "H I G H E S T   A N D  L O W E S T" ;
	gotoxy(24,7);cout << "INSTRUCTION: ENTER 10 NUMBERS AND DISPLAY 1ST AND 2ND TO THE HIGHEST NUMBER " ;
	gotoxy(44,8);cout << "AND 1ST AND 2ND TO THE LOWEST NUMBER. \n\n";
	border_in();

 	gotoxy(33,13);cout<<"ENTER 10 NUMBERS: \n";   
	 
    for(int i=0; i<10; i++)
     { 
    gotoxy(33,14+i);cin>>num[i];
    	while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
     } 

    if(num[0]<num[1])
     { 
        largest = num[1]; 
        second = num[0]; 
     } else{ 
        largest = num[0]; 
        second = num[1];
     } 
     for (int i=2; i<10 ; i ++)
     { 
      if (num[i] > largest) 
       { 
            second = largest; 
            largest = num[i];
       }
    else if(num[i] > second && num[i] != largest)
         { 
       second = num[i]; 
         } 
        } 
    gotoxy(60,15);cout<<"First to the Highest: "<<largest<<"\n"; 
    gotoxy(60,17); cout<<"Second to the Highest: "<<second<<"\n";
	 
	lowest = secondlow;  
    for (int i = 0; i < 10 ; i ++)  
    {  
        if (num[i] < lowest)  
        {  
            secondlow = lowest;  
           	lowest = num[i];  
        }  
  
        else if (num[i] < secondlow && num[i] != lowest)  
            secondlow = num[i];  
        }
        
    	gotoxy(60,19);cout<<"First to the Lowest: "<<lowest<<"\n"; 
     	gotoxy(60,21);cout<<"Second to the Lowest: "<<secondlow<<"\n"<<endl;
     int b;
	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> b;
	if(b==1)
	{
		return highlow();
	}
	else if(b==2)
	{
		return main();
	}
	else if(b==3)
	{
		exit(0);
	}
}

////////////////////////////////
int palindrome ()
	{
	system ("COLOR 08");
	system("CLS");
	char word[50];
    int i, length;
    int j = 0;
    border_out();
	gotoxy(47,5); cout << "P A L I N D R O M E" ;
	gotoxy(29,7);cout << "INSTRUCTION: ENTER A WORD AND DISPLAY IF IT IS A PALINDROME OR NOT. \n\n";
	border_in();
    
    gotoxy(47,17);cout << "ENTER A WORD: "; 
	gotoxy(62,17);cin >> word;
		while(1)
{
if(cin.fail())
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(),'\n');
gotoxy(45,25);cout<<"I N V A L I D  I N P U T ! ! !" << endl;
return 0;
}
if(!cin.fail())
break;
}
	
    length = strlen(word);
    
    for(i=0;i < length ;i++){
        if(word[i] != word[length-i-1]){
            j = 1;
            break;
   }
}
    
    if (j) {
        gotoxy(47,23);cout << word << " IS NOT A PALINDROME" << endl; 
    }    
    else {
        gotoxy(47,23);cout << word << " IS A PALINDROME" << endl; 
    }
int b;
	gotoxy(47,33);cout << "Press (1) TRY AGAIN";
	gotoxy(47,34);cout << "Press (2) BACK TO MENU";
	gotoxy(47,35); cout << "Press (3) EXIT";
	gotoxy(47,36); cout << "Select one: ";
	cin >> b;
	if(b==1)
	{
		return palindrome();
	}
	else if(b==2)
	{
		return main();
	}
	else if(b==3)
	{
		exit(0);
	}
}


