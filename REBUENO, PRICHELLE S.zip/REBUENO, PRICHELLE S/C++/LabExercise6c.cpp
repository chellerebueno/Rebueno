#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	//depends where 'sample.txt' file is located
	fp=fopen("d:\\myfiles\\sample.txt","a");
	if(!fp)
	{
		cout << "Cannot open file. \n";
		system ("pause");
		exit(1);
	}
	fputc('\n', fp);
	for (int i = 97;i<123;i++)
		fputc(i, fp);
	fclose(fp);
	return 0;
}
